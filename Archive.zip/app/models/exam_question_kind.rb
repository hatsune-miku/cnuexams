class ExamQuestionKind < ApplicationRecord
    belongs_to :exam
end
