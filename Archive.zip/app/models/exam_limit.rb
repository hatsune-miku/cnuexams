class ExamLimit < ApplicationRecord
end
