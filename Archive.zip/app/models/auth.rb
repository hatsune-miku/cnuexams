class Auth < ApplicationRecord
end
