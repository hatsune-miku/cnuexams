class Institute < ApplicationRecord
end
