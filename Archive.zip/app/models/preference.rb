class Preference < ApplicationRecord
end
