class Customcate < ApplicationRecord
end
