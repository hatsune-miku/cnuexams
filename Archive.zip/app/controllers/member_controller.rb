class MemberController < ApplicationController
    def create
        index
    end

    def index

    end
end
