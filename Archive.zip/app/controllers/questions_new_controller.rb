class QuestionsNewController < ApplicationController

end
