class MainController < ApplicationController
    def index
        create
    end

    def create

    end
end
