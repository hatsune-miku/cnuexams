module AuthsHelper
end
