require 'test_helper'

class InstituteTest < ActiveSupport::TestCase
  # test "the truth" do
  #   assert true
  # end
end
