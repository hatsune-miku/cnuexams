require 'test_helper'

class QuestionsNewTest < ActiveSupport::TestCase
  # test "the truth" do
  #   assert true
  # end
end
