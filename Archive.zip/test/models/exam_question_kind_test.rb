require 'test_helper'

class ExamQuestionKindTest < ActiveSupport::TestCase
  # test "the truth" do
  #   assert true
  # end
end
