require 'test_helper'

class PreferenceTest < ActiveSupport::TestCase
    # Preference.create(name: 'login_limit', value: '3')
end
