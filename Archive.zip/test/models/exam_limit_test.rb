require 'test_helper'

class ExamLimitTest < ActiveSupport::TestCase

end
