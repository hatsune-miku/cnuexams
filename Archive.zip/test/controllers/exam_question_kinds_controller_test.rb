require 'test_helper'

class ExamQuestionKindsControllerTest < ActionDispatch::IntegrationTest
  # test "the truth" do
  #   assert true
  # end
end
